package com.glavesoft.pawnuser.mod;

/**
 * @author 严光
 * @date: 2017/10/28
 * @company:常州宝丰
 */
public class PawnCateInfo {
    private String cateType;
    private String code;
    private String icon;
    private String id;
    private String name;

    public String getCateType() {
        return cateType;
    }

    public void setCateType(String cateType) {
        this.cateType = cateType;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
