package com.glavesoft.view;

public interface OnTimeSetListener {
	void onTimeSet(String time);
}	
