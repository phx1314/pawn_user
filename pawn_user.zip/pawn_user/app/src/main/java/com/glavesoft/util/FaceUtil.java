package com.glavesoft.util;

/**
 * @author 严光
 * @date: 2017/11/16
 * @company:常州宝丰
 * @description:
 * @version:3.0.0
 */
public class FaceUtil {

    //在这边填写 API_KEY 和 API_SECRET
    public static String API_KEY = "ZNu_V9MPjuwfqUkyMhb3H2AiBdxroNAa";
    public static String API_SECRET = "c-Lb64e53floMklZ2l-kbIfWRGKet7nZ";
}
