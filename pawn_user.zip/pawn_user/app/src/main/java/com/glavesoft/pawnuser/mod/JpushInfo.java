package com.glavesoft.pawnuser.mod;

public class JpushInfo {
	private String msg;
	private String redirectContent;
	private String redirectType;

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getRedirectContent() {
		return redirectContent;
	}

	public void setRedirectContent(String redirectContent) {
		this.redirectContent = redirectContent;
	}

	public String getRedirectType() {
		return redirectType;
	}

	public void setRedirectType(String redirectType) {
		this.redirectType = redirectType;
	}
}
