package com.glavesoft.pawnuser.mod;

/**
 * @author 严光
 * @date: 2017/8/30
 * @company:常州宝丰
 */
public class UploadPicInfo {
    private int index;
    private int itemindex;
    private String url;

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public int getItemindex() {
        return itemindex;
    }

    public void setItemindex(int itemindex) {
        this.itemindex = itemindex;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
