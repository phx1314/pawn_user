package com.glavesoft.pawnuser.mod;

/**
 * Created by Sinyu on 2018/8/5.
 */

public class MostThreeGoodsInfo {


    /**
     * cateCode : 2
     * cateName :
     * cost : 600
     * createTime : 2018-06-05 10:46:15
     * estate :
     * goodsId : 0
     * height : 1
     * id : 543
     * img : 15263ddc7f0c4e6f8ceea9c52dfbe36d
     * imgs : 06eb0ca8fac145a4b6dfed3ae631ec77,44e746db297846e4826f612e500f9b60
     * info : 平台编号：BG17030332<br />
     尺寸：长39.35mm 宽25.59mm 高4.95mm<br />
     质量：10.35g<br />
     <img alt="" src="/paidangAdmin/download?id=683bcdfb95014a6dae2e71b5e12d907f" /><img alt=""
     src="/paidangAdmin/download?id=683bcdfb95014a6dae2e71b5e12d907f" /><img alt=""
     src="/paidangAdmin/download?id=57c7359a8cee445483c9982b2a7cc1ea" /><br />
     * isOnline : 1
     * isSuggest : 0
     * isVerfiy : 2
     * maxAuction : 0
     * maxAutionId : 0
     * modifyTime : null
     * myPrice :
     * name : 天然翡翠灵芝挂件
     * orderCode :
     * orgId : 0
     * orgName :
     * platformMoney : 0
     * platformRate : 0
     * platformState : 0
     * price : 600
     * shelfDown :
     * shipCode :
     * shipFirm :
     * soldOut : 1
     * soldPrice : 0
     * sortOrder : 0
     * source : 2
     * spec : 1
     * state : 1
     * total : 0
     * type : 2
     * userId : 0
     * width : 1
     */

    private String cateCode;
    private String cateName;
    private String cost;
    private String createTime;
    private String estate;
    private String goodsId;
    private String height;
    private String id;
    private String img;
    private String imgs;
    private String info;
    private String isOnline;
    private String isSuggest;
    private String isVerfiy;
    private String maxAuction;
    private String maxAutionId;
    private Object modifyTime;
    private String myPrice;
    private String name;
    private String orderCode;
    private String orgId;
    private String orgName;
    private String platformMoney;
    private String platformRate;
    private String platformState;
    private String price;
    private String shelfDown;
    private String shipCode;
    private String shipFirm;
    private String soldOut;
    private String soldPrice;
    private String sortOrder;
    private String source;
    private String spec;
    private String state;
    private String total;
    private String type;
    private String userId;
    private String width;

    public String getCateCode() {
        return cateCode;
    }

    public void setCateCode(String cateCode) {
        this.cateCode = cateCode;
    }

    public String getCateName() {
        return cateName;
    }

    public void setCateName(String cateName) {
        this.cateName = cateName;
    }

    public String getCost() {
        return cost;
    }

    public void setCost(String cost) {
        this.cost = cost;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getEstate() {
        return estate;
    }

    public void setEstate(String estate) {
        this.estate = estate;
    }

    public String getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(String goodsId) {
        this.goodsId = goodsId;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getImgs() {
        return imgs;
    }

    public void setImgs(String imgs) {
        this.imgs = imgs;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getIsOnline() {
        return isOnline;
    }

    public void setIsOnline(String isOnline) {
        this.isOnline = isOnline;
    }

    public String getIsSuggest() {
        return isSuggest;
    }

    public void setIsSuggest(String isSuggest) {
        this.isSuggest = isSuggest;
    }

    public String getIsVerfiy() {
        return isVerfiy;
    }

    public void setIsVerfiy(String isVerfiy) {
        this.isVerfiy = isVerfiy;
    }

    public String getMaxAuction() {
        return maxAuction;
    }

    public void setMaxAuction(String maxAuction) {
        this.maxAuction = maxAuction;
    }

    public String getMaxAutionId() {
        return maxAutionId;
    }

    public void setMaxAutionId(String maxAutionId) {
        this.maxAutionId = maxAutionId;
    }

    public Object getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Object modifyTime) {
        this.modifyTime = modifyTime;
    }

    public String getMyPrice() {
        return myPrice;
    }

    public void setMyPrice(String myPrice) {
        this.myPrice = myPrice;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOrderCode() {
        return orderCode;
    }

    public void setOrderCode(String orderCode) {
        this.orderCode = orderCode;
    }

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public String getPlatformMoney() {
        return platformMoney;
    }

    public void setPlatformMoney(String platformMoney) {
        this.platformMoney = platformMoney;
    }

    public String getPlatformRate() {
        return platformRate;
    }

    public void setPlatformRate(String platformRate) {
        this.platformRate = platformRate;
    }

    public String getPlatformState() {
        return platformState;
    }

    public void setPlatformState(String platformState) {
        this.platformState = platformState;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getShelfDown() {
        return shelfDown;
    }

    public void setShelfDown(String shelfDown) {
        this.shelfDown = shelfDown;
    }

    public String getShipCode() {
        return shipCode;
    }

    public void setShipCode(String shipCode) {
        this.shipCode = shipCode;
    }

    public String getShipFirm() {
        return shipFirm;
    }

    public void setShipFirm(String shipFirm) {
        this.shipFirm = shipFirm;
    }

    public String getSoldOut() {
        return soldOut;
    }

    public void setSoldOut(String soldOut) {
        this.soldOut = soldOut;
    }

    public String getSoldPrice() {
        return soldPrice;
    }

    public void setSoldPrice(String soldPrice) {
        this.soldPrice = soldPrice;
    }

    public String getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(String sortOrder) {
        this.sortOrder = sortOrder;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getSpec() {
        return spec;
    }

    public void setSpec(String spec) {
        this.spec = spec;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getWidth() {
        return width;
    }

    public void setWidth(String width) {
        this.width = width;
    }
}
