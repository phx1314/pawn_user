package com.glavesoft.pawnuser.mod;

/**
 * @author 严光
 * @date: 2017/10/28
 * @company:常州宝丰
 */
public class OnlineIdentificationInfo {

    private String name;
    private String content;
    private String contentType;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }
}
