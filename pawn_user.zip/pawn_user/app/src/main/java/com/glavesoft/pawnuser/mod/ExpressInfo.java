package com.glavesoft.pawnuser.mod;

/**
 * @author 严光
 * @date: 2018/2/1
 * @company:常州宝丰
 */
public class ExpressInfo {
    private String context;
    private String time;
    private String ftime;

    public String getContext() {
        return context;
    }

    public void setContext(String context) {
        this.context = context;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getFtime() {
        return ftime;
    }

    public void setFtime(String ftime) {
        this.ftime = ftime;
    }
}
