package com.glavesoft.pawnuser.mod;

/**
 * Created by Sinyu on 2018/8/6.
 */

public class VideoSeachInfo {

    /**
     * createTime : 2018-07-03 11:31:34
     * id : 41
     * img : 0935e50ba35e42c881a7414225e457b2_cut
     * isSuggest : 0
     * state : 0
     * title : 艺术品
     * video : 0935e50ba35e42c881a7414225e457b2
     * viewCnt : 0
     */

    private String createTime;
    private int id;
    private String img;
    private int isSuggest;
    private int state;
    private String title;
    private String video;
    private int viewCnt;

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public int getIsSuggest() {
        return isSuggest;
    }

    public void setIsSuggest(int isSuggest) {
        this.isSuggest = isSuggest;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getVideo() {
        return video;
    }

    public void setVideo(String video) {
        this.video = video;
    }

    public int getViewCnt() {
        return viewCnt;
    }

    public void setViewCnt(int viewCnt) {
        this.viewCnt = viewCnt;
    }
}
