package com.glavesoft.pawnuser.mod;

/**
 * @author 严光
 * @date: 2018/2/2
 * @company:常州宝丰
 */
public class LawInfo {

    private String code;
    private String remark;//标记
    private String value;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
