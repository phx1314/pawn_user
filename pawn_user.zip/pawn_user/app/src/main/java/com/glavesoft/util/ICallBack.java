package com.glavesoft.util;

/**
 * 创建时间：2017-9-20 下午3:37:55
 * 项目名称：IndexActivity
 *
 * @author liqi
 * @version 1.0
 * @since JDK 1.6.0_21
 * 文件名称：TTS.java
 * 类说明：
 */

/**
 * 播报回调类
 */
public interface ICallBack {
    void onCompleted(int code);
}
