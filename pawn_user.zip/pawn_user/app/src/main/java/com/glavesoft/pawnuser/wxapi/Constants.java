package com.glavesoft.pawnuser.wxapi;

public class Constants
{
	// APP_ID 替换为你的应用从官方网站申请到的合法appId
	public static final String APP_ID = "wx619518fc8722b2e1";
	public static final String MCH_ID = "1517519131";
	public static final String KEY = "m2JgCHs66539Idhb7YlGbAwDnZ94Wjxr";

	public static class ShowMsgActivity{
		public static final String STitle = "showmsg_title";
		public static final String SMessage = "showmsg_message";
		public static final String BAThumbData = "showmsg_thumb_data";
	}
}
