package com.glavesoft.pawnuser.mod;

public class IsNeedComment {

    private boolean data;

    public boolean isData() {
        return data;
    }

    public void setData(boolean data) {
        this.data = data;
    }
}
