package com.glavesoft.pawnuser.mod;

/**
 * @author 严光
 * @date: 2017/10/30
 * @company:常州宝丰
 */
public class BxAddressInfo {
    private String address;
    private String phone;
    private String name;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
