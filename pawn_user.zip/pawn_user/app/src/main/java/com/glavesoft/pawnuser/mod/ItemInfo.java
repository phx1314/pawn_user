package com.glavesoft.pawnuser.mod;

/**
 * @author 严光
 * @date: 2018/1/15
 * @company:常州宝丰
 */
public class ItemInfo {
    private String title;
    private int img;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }
}
