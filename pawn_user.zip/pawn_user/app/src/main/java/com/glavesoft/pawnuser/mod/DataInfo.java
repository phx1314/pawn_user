package com.glavesoft.pawnuser.mod;

/**
 * @author 严光
 * @date: 2017/10/28
 * @company:常州宝丰
 */
public class DataInfo {
    private String code="";
    private String msg="";
    private String data="";
    private String replyCnt;
    private String dangpiao;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getReplyCnt() {
        return replyCnt;
    }

    public void setReplyCnt(String replyCnt) {
        this.replyCnt = replyCnt;
    }

    public String getDangpiao() {
        return dangpiao;
    }

    public void setDangpiao(String dangpiao) {
        this.dangpiao = dangpiao;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
