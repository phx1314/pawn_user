package com.glavesoft.pawnuser.mod;

public class StaggeredModel {
    public String icon;
    public String desc;
}