package com.glavesoft.pawnuser.activity.video;

/**
 * Created by Administrator on 2017/8/24.
 */
public class VideoConstant {

    public static String[][] videoUrls =
            {
                    {
                            "http://video.jiecao.fm/8/18/%E5%A4%A7%E5%AD%A6.mp4",
                            "http://video.jiecao.fm/11/24/xin/-%2024%20-%20.mp4",
                            "http://video.jiecao.fm/11/23/6/%E7%8B%97.mp4",
                    }
            };

    public static String[][] videoThumbs =
            {
                    {
                            "http://img4.jiecaojingxuan.com/2016/8/18/ccd86ca1-66c7-4331-9450-a3b7f765424a.png",
                            "http://img4.jiecaojingxuan.com/2016/11/24/f18ee453-6aec-40a5-a046-3203111dd303.jpg@!640_360",
                            "http://img4.jiecaojingxuan.com/2016/11/23/7df34ee9-1e4f-48f4-8acd-748c52368298.jpg@!640_360",
                    }
            };

    public static String[][] videoTitles =
            {
                    {
                            "哈哈哈哈哈1",
                            "哈哈哈哈哈2",
                            "哈哈哈哈哈3",
                    }
            };

}
