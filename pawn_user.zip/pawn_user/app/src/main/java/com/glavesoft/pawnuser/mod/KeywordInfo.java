package com.glavesoft.pawnuser.mod;

/**
 * @author 严光
 * @date: 2017/12/27
 * @company:常州宝丰
 */
public class KeywordInfo {
    private String id;
    private String name;//名字

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
