package com.glavesoft.volley.form;

public class FormFile {

    private String mName ;

    private String mValue ;

    private String mMime ;
}
