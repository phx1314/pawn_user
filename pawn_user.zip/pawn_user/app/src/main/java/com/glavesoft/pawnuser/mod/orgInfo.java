package com.glavesoft.pawnuser.mod;

/**
 * @author 严光
 * @date: 2017/12/4
 * @company:常州宝丰
 */
public class orgInfo {
    private String orgId;//商家id
    private String orgName;//商家名称

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }
}
