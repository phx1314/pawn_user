package com.glavesoft.pawnuser.mod;

/**
 * @author 严光
 * @date: 2018/1/10
 * @company:常州宝丰
 */
public class PersonMenuInfo {

    private int drawable;
    private String title;
    private int num;

    public int getDrawable() {
        return drawable;
    }

    public void setDrawable(int drawable) {
        this.drawable = drawable;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }
}
