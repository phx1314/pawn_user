package com.glavesoft.pawnuser.mod;

/**
 * Created by Sinyu on 2018/8/6.
 */

public class SeachOrgInfo {

    /**
     * account : baoxiang
     * adress : 常州市延陵西路23、25、27、29号
     * balance : 0
     * businessLicense : 3c0e727051964bd9bde6dea481295a88
     * businessLicenseCode : 320400000003446
     * createTime : 2017-11-06 15:56:57
     * expirationRemindType : 0
     * id : 0
     * Stringroduction :
     * legalPerson : 黄震
     * modifyTime : null
     * name : 常州宝祥典当行有限公司
     * orgImages : 2b6e2935744e4e90b480a4e0d5c15a65
     * orgLogo : 4ddca1de78ed4523abfef64376264994
     * overdueRate : 0
     * password : c4ca4238a0b923820dcc509a6f75849b
     * pawnState : 1
     * phone : 13775088918
     * redeemOverrate : 2.5
     * registeredCapital : 4800万
     * roleCode : org_admin
     * seal : 030b5934b2b74eac875436e99c8e322a
     * state : 1
     * type : 1
     */

    private String account;
    private String adress;
    private String balance;
    private String businessLicense;
    private String businessLicenseCode;
    private String createTime;
    private String expirationRemindType;
    private String id;
    private String Stringroduction;
    private String legalPerson;
    private Object modifyTime;
    private String name;
    private String orgImages;
    private String orgLogo;
    private String overdueRate;
    private String password;
    private String pawnState;
    private String phone;
    private double redeemOverrate;
    private String registeredCapital;
    private String roleCode;
    private String seal;
    private String state;
    private String type;
    private String goodsImgs;

    public String getGoodsImgs() {
        return goodsImgs;
    }

    public void setGoodsImgs(String goodsImgs) {
        this.goodsImgs = goodsImgs;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getAdress() {
        return adress;
    }

    public void setAdress(String adress) {
        this.adress = adress;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    public String getBusinessLicense() {
        return businessLicense;
    }

    public void setBusinessLicense(String businessLicense) {
        this.businessLicense = businessLicense;
    }

    public String getBusinessLicenseCode() {
        return businessLicenseCode;
    }

    public void setBusinessLicenseCode(String businessLicenseCode) {
        this.businessLicenseCode = businessLicenseCode;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getExpirationRemindType() {
        return expirationRemindType;
    }

    public void setExpirationRemindType(String expirationRemindType) {
        this.expirationRemindType = expirationRemindType;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStringroduction() {
        return Stringroduction;
    }

    public void setStringroduction(String Stringroduction) {
        this.Stringroduction = Stringroduction;
    }

    public String getLegalPerson() {
        return legalPerson;
    }

    public void setLegalPerson(String legalPerson) {
        this.legalPerson = legalPerson;
    }

    public Object getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Object modifyTime) {
        this.modifyTime = modifyTime;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOrgImages() {
        return orgImages;
    }

    public void setOrgImages(String orgImages) {
        this.orgImages = orgImages;
    }

    public String getOrgLogo() {
        return orgLogo;
    }

    public void setOrgLogo(String orgLogo) {
        this.orgLogo = orgLogo;
    }

    public String getOverdueRate() {
        return overdueRate;
    }

    public void setOverdueRate(String overdueRate) {
        this.overdueRate = overdueRate;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPawnState() {
        return pawnState;
    }

    public void setPawnState(String pawnState) {
        this.pawnState = pawnState;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public double getRedeemOverrate() {
        return redeemOverrate;
    }

    public void setRedeemOverrate(double redeemOverrate) {
        this.redeemOverrate = redeemOverrate;
    }

    public String getRegisteredCapital() {
        return registeredCapital;
    }

    public void setRegisteredCapital(String registeredCapital) {
        this.registeredCapital = registeredCapital;
    }

    public String getRoleCode() {
        return roleCode;
    }

    public void setRoleCode(String roleCode) {
        this.roleCode = roleCode;
    }

    public String getSeal() {
        return seal;
    }

    public void setSeal(String seal) {
        this.seal = seal;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
